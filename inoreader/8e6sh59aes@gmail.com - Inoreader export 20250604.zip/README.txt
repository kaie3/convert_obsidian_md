This archive was exported from Inoreader on Wed, 04 Jun 2025 11:14:49 +0000
Most RSS Readers only need subscriptions.xml file, so if you get an error while uploading the zip file, try to extract subscriptions.xml and upload it directly.

Statistics:

Number of feeds: 60
Number of folders: 10
Number of tags: 0
Number of stars: 4991
Number of saved web pages: 0
Export duration: 4 sec.

-- 
https://www.inoreader.com